package com.example.testassessment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestAssessmentApplication {

    public static void main(String[] args) {
        SpringApplication.run(TestAssessmentApplication.class, args);
    }

}
